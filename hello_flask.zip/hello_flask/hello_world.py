from flask import Flask 
from flask import render_template  # Import Flask to allow us to create our app.
app = Flask(__name__)    # Global variable __name__ tells Flask whether or not we are running the file
                         # directly, or importing it as a module.
@app.route('/')          
def hello_world():
  return render_template('index.html')    
app.run(debug=True)                             
'''                         # localhost:5000/ we will run the following "hello_world" function.
def hello_world():
  return 'Hello World!'  # Return the string 'Hello World!' as a response.
app.run(debug=True) 
'''
